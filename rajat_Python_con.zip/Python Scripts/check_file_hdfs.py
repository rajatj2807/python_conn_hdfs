from hdfs import InsecureClient
logging.debug("fgjwhgfjhdg")
client =InsecureClient('http://bancloudbox01.r2dl.com:50070')
logging.debug("Connection Created")




def check_data(path):
    print('in convertToParquet')
    if not client.content(path,strict=True):
		client.makedirs(folder)

print(folder)
        
        

        
        
        
