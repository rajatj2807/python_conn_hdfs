import subprocess
p = subprocess.Popen("hdfs dfs -ls -R <HDFS Location> |  awk '{print $8}"> output.txt,
    shell=True,
    stdout=subprocess.PIPE,
    stderr=subprocess.STDOUT)

for line in p.stdout.readlines():
    print (line)