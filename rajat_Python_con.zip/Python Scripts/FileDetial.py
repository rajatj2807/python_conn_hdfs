import os
dirlist = os.listdir("C://CiaB")
dirsize = os.path.getsize('C://CiaB')
list = os.listdir('C://CiaB')
number_files = len(list)


from pprint import pprint
pprint(dirlist)
pprint(dirsize)
pprint(number_files)