
import glob
import hashlib
import datetime
import time
import json
import subprocess
import pickle
import portalocker
import logging
import posixpath as psp


from hdfs import InsecureClient
client =InsecureClient('http://bancloudbox01.r2dl.com:50070')

print("connection done")

def get_file_info_from_dictionary(path):
    for dirpath,dirnames,filenames in client.walk(path,depth=0,status=False):
        #print ('dirpath',dirpath)
        #print ('dirnames',dirnames)
        #print ('filenames',filenames)
        for f in filenames:
            full_file_path = dirpath+'/'+f
            check_sum_from_hdfs(full_file_path)
            #print (full_file_path)

def check_sum_from_hdfs(full_file_path):
    results = client.checksum(full_file_path)
    print(results)
    
        

c = get_file_info_from_dictionary("/data/landing/001_EHM_SORTT/TRENT_1000/20180201_to_20180611.ignore/")
