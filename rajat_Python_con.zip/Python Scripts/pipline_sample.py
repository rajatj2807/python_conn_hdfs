#!/usr/bin/python3

import glob
import hashlib
import os
import datetime
import time
import json
import subprocess
import pickle
import portalocker
import logging
import posixpath as psp


logging.basicConfig(filename='HDFS1.log',level=logging.DEBUG)

from hdfs import InsecureClient
logging.debug("fgjwhgfjhdg")
client =InsecureClient('http://bancloudbox01.r2dl.com:50070')
logging.debug("Connection Created")


def getTopFolders(root, pattern):
    results = []
    results = client.list(root,status=False)
    print("pipline",results)
    results = sorted(results)
    logging.debug("Getting the files present in the location")
    return results

def getTopListFolders(root,pattern):
    tasks = []
    for filename in glob.iglob(root + pattern):
        tasks.append(filename)

    tasks = sorted(tasks)
    print('Tasks are',tasks)
    return tasks

def getHdfsfolderSize(path):
    
    s = 0
    c = 0
    for dirpath,dirnames,filenames in client.walk(path,depth=0,status=False):
                print ('dirpath',dirpath)
                #print ('dirnames',dirnames)
                #print ('filenames',filenames)
                for f in filenames:
                    fp = psp.join(dirpath,path)
            #fp = client.join(dirpath,f)
                    #print (fp)
                    file_detials = client.content(fp,True)
                    print (file_detials)
                    s += file_detials['length']
                    c += 1
                    #s += client.getsize(fp)
                    #c += 1
    return {'Size' : s, 'Count': c}
        
    
    
def generateFileHash(file):
    hash_md5 = hashlib.md5()
    with open(file, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
          hash_md5.update(chunk)
	return hash_md5.hexdigest()

def getFolderSize(path):
#def getFolderSize(root):
  s = 0
  c = 0
  for dirpath, dirnames, filenames in os.walk(path):
    print (dirpath)
    print (dirnames)
    print (filenames)
    for f in filenames:
        fp = os.path.join(dirpath, f)
        s += os.path.getsize(fp)
        c += 1
	return {'Size' : s, 'Count': c}


def createQuickFileDetails(file):
    key = {}
    key['mtime'] = os.path.getmtime(file)
    key['filename'] = file
    return key

def runPipeline(pipeline, basePath):
    if basePath.lower().endswith('.ignore'):
        print('Skipping the folder ' + basePath)
        return

    print(basePath + ' - ' + str(pipeline))
    print("adfasdfds")
    tasks = getTopListFolders(pipeline["Pipeline"],'/*')
    print("line 79")
    print("tasks are",tasks)
    tasks.sort()

    pipeline_config = {}
        
    pickleFile = pipeline['Pipeline'] + "/pipeline_config.p"
    print("line 89")
    print('Using pickle: ' + pickleFile)
    try:
        if os.path.exists(pickleFile):
            os.remove(pickleFile)
    except Exception as ex:
        print('Failed to process data - it will be tried again')
        print(str(ex))
        pipeline_config['ChangedBasePath'] = basePath
        print (pipeline_config)


    with open(pickleFile, 'wb') as f:
        pickle.dump(pipeline_config, f)

    wd = pipeline['Pipeline']
    for t in tasks:
        print("Running task " + t)

		if t.lower().endswith('.ipynb'):
			p = subprocess.Popen(["jupyter", "nbconvert", "--ExecutePreprocessor.timeout=0", "--execute", t], cwd=wd)
			p.wait()
			if p.returncode != 0:
				raise Exception('Error ' + str( p.returncode) + ' returned from ' + t)
			elif t.lower().endswith('.py'):
				p = subprocess.Popen(["python3", t], cwd=wd)
				p.wait()
				if p.returncode != 0:
					raise Exception('Error ' + str( p.returncode) + ' returned from ' + t)
		else:
			continue
#location of pickle file
      
pickleFile = 'fileList.p'

# TODO - the known list must be saved!!
try:
    with open(pickleFile, 'rb') as f:
        knownFiles = pickle.load(f)
except:
    knownFiles = {}
    print('Failed to load last state, rebuilding...')

print('Checking for new files in landing...')

# Keep the file locked until we are done!
try:
    with open('test_pipelines.json', 'r+') as jsonFile:
        portalocker.lock(jsonFile, portalocker.LOCK_EX | portalocker.LOCK_NB)
        pipelines = json.load(jsonFile)

        for pipeline in pipelines:
            print('Pipeline: ' + pipeline['Folder'])

            filesToCheck = getTopFolders(pipeline['Folder'], '/*')
            for file in filesToCheck:

                print("file in ",file)
                now = datetime.datetime.utcnow()
                filesizeandcount = getHdfsfolderSize(file)
                #filesizeandcount = getFolderSize(pipeline['Folder'])
                print (filesizeandcount)
                if file in knownFiles:
                    if knownFiles[file]['Size'] == filesizeandcount['Size'] and knownFiles[file]['Count'] == filesizeandcount['Count']:
                    # NoChange
                        knownFiles[file]['Size'] = filesizeandcount['Size']
                        knownFiles[file]['Count'] = filesizeandcount['Count']
                        knownFiles[file]['LastUpdate'] = now 

                        if knownFiles[file]['LastRunSizeAndCount'] == None or knownFiles[file]['LastRunSizeAndCount']['Size'] !=  filesizeandcount['Size'] or knownFiles[file]['LastRunSizeAndCount']['Count'] !=  filesizeandcount['Count']:
                            
                            #TODO - check age of data for now assume this is not run frequently
                      # The number of files has not changed, so assume it has finished!

                            try:
                                runPipeline(pipeline, file)
                                knownFiles[file]['LastRunSizeAndCount'] = filesizeandcount
                                knownFiles[file]['LastRun'] = now
                            except Exception as ex:
                                print('Failed to process data - it will be tried again')
                                print(str(ex))
                        else:
                      # The size or number of files has changed, try again later
							continue
                    else:
                        # The total filesize or number of files has changed, wait longer
                        knownFiles[file]['Size'] = filesizeandcount['Size']
                        knownFiles[file]['Count'] = filesizeandcount['Count']
                        knownFiles[file]['LastUpdate'] = now
					continue

                knownFiles[file] = { 'File': file, 'LastUpdate': datetime.datetime.utcnow(), 'Size': filesizeandcount['Size'], 'Count': filesizeandcount['Count'], 'LastRun': None, 'LastRunSizeAndCount': None}

            with open(pickleFile, 'wb') as f:
                pickle.dump(knownFiles, f)

        except portalocker.LockException:
            print('Failed lock file because the script is already running')
