import os
from os.path import join, getsize

path ="C:\\CiaB\data\\015_Weight_Data\\TRENT_1000\\Balance_Data"

print("root prints out directories only from what you specified")
print("dirs prints out sub-directories from root")
print("files prints out all files from root and directories")
print("*" * 20)

Linux_files=[]
for root, dirs, files in os.walk(path):
    print("Current Directory",root)
    print("Directory found",dirs)
    print("len of the files in this location" ,root ,"is",len(files))
    print("This location",root, "files consumes",sum([getsize(join(root, name)) for name in files]))

'''
def count(dir, counter=0):
    "returns number of files in dir and subdirs"
    for pack in os.walk(dir):
        print (pack)
        for f in pack[2]:
            counter += 1
    return dir + " : " + str(counter) + "files"



print(count(path))
'''