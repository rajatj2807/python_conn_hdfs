import os

path = "/home/rajatj/sample/sample1/sample2"
os.chdir(path)
data = os.popen('-du -a -h | sort -hr >output.txt').read()
print(data)
with open('output.txt','r') as p:
    print(len(p))



#hadoop fs -ls -R -h /data/landing/location of the folder > EHM..txt
#ll
