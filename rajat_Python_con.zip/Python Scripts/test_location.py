import os
import glob
import posixpath as psp
import logging

from hdfs import InsecureClient
logging.debug("fgjwhgfjhdg")
client =InsecureClient('http://bancloudbox01.r2dl.com:50070')

def __init__(self):
    self.current_number = 0
    self.logger = logging.getLogger(__name__)

    # Create the Logger
    self.logger = logging.getLogger(__name__)
    self.logger.setLevel(logging.DEBUG)

    # Create the Handler for logging data to a file
    logger_handler = logging.FileHandler('python_logging.log')
    logger_handler.setLevel(logging.DEBUG)

    # Create a Formatter for formatting the log messages
    logger_formatter = logging.Formatter('%(name)s - %(levelname)s - %(message)s')

    # Add the Formatter to the Handler
    logger_handler.setFormatter(logger_formatter)

    # Add the Handler to the Logger
    self.logger.addHandler(logger_handler)
    self.logger.info('Completed configuring logger()!')


def getFolderSize(self,path):
  s = 0
  c = 0
  for dirpath, dirnames, filenames in os.walk(path):
    for f in filenames:
      fp = os.path.join(dirpath, f)
      s += os.path.getsize(fp)
      c += 1
  return {'Size' : s, 'Count': c}

def getTopListFolders(self,root,pattern):
    tasks = []
    self.logger.warning("Fetching the details of the directory")
    for filename in glob.iglob(root + pattern):
        tasks.append(filename)

    tasks = sorted(tasks)
    print('Tasks are',tasks)
    self.logger.info("Count and Size of files")
    return tasks

def getHdfsfolderSize(self,path):
    
    s = 0
    c = 0
    for dirpath,dirnames,filenames in client.walk(path,depth=0,status=False):
        self.logger.warning("Fetching the details of the directory")
        for f in filenames:
            fp = psp.join(dirpath,path)
            file_detials = client.content(fp,True)
            s += file_detials['length']
            c += 1
            self.logger.info("Count and Size of files")
    return {'Size' : s, 'Count': c}


''' Another way of implementing it
    fpaths = [psp.join(dpath, fname) for dpath, _, fnames in client.walk(path)for fname in fnames]
    print (fpaths)
    print(client.content(fpaths,False))
    
'''    
    

#a = getFolderSize('C:\\CiaB\data\\015_Weight_Data\\TRENT_1000')
b=  getTopListFolders('C:\\CiaB\data\\015_Weight_Data\\TRENT_1000','/*.*')
##print(c)

#print(a)
#print(b)

