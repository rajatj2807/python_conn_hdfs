import sqlite3
import logging
from hdfs import InsecureClient



logging.basicConfig(filename='conversion.log',level=logging.DEBUG)


client =InsecureClient('http://bancloudbox01.r2dl.com:50070')
logging.debug("Connection Created")


def loadData():
    with client.read("/data/landing/001_EHM_SORTT/TRENT_900/SQLITE/20180525/t900.db") as reader:
        sqlite_data = reader.read()
        print(len(sqlite_data))
        
a= loadData()
        
        





    