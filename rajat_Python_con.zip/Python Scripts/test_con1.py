import pandas as pd
from hdfs import InsecureClient
import os


client_hdfs = InsecureClient('http://bancloudbox01.r2dl.com:8020')
liste_hello = ['hello1','hello2']
liste_world = ['world1','world2']
df = pd.DataFrame(data = {'hello':'liste_hello','world':'liste_world'})

with client_hdfs.write('/tmp/helloworld.csv',encoding = 'utf-8') as writer:
    df.to_csv(writer)
    
