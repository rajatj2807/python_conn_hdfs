import os
from os.path import join, getsize

def count(dir, counter=0):
    "returns number of files in dir and subdirs"
    for pack in os.walk(dir):
        print (pack)
        for f in pack[2]:
            counter += 1
    return dir + " : " + str(counter) + "files"



print(count("C:\CiaB\CIAB_CODES\LookupData_T700"))
#print(count("C:\Users\c_jainR\Documents\"))
